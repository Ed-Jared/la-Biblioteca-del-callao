import csv  # Permite leer y escribir archivos CSV
from datetime import datetime  # Permite obtener la fecha y hora actual

ARCHIVO = "expedientes.csv"  # Nombre del archivo donde se guardan los datos
ENCABEZADOS = [  # Nombres de las columnas del archivo CSV
    "codigo",
    "dni",
    "ciudadano",
    "tipo_documento",
    "asunto",
    "descripcion",
    "fecha_recepcion",
    "area_responsable",
    "estado",
]


def cargar_expedientes():
    """Lee el archivo CSV y devuelve una lista de expedientes."""
    expedientes = []
    try:
        # Abre el archivo en modo lectura ("r") con codificación UTF-8
        with open(ARCHIVO, "r", newline="", encoding="utf-8") as archivo:
            lector = csv.reader(archivo)
            next(lector, None)  # Salta la primera fila (los encabezados)
            for fila in lector:
                # Verifica que la fila tenga todas las columnas esperadas
                if len(fila) == len(ENCABEZADOS):
                    expedientes.append({
                        "codigo": fila[0],
                        "dni": fila[1],
                        "ciudadano": fila[2],
                        "tipo_documento": fila[3],
                        "asunto": fila[4],
                        "descripcion": fila[5],
                        "fecha_recepcion": fila[6],
                        "area_responsable": fila[7],
                        "estado": fila[8],
                    })
    except FileNotFoundError:
        # Si el archivo aún no existe, no muestra error y retorna vacío
        pass
    return expedientes


def guardar_expedientes(expedientes):
    """Guarda toda la lista de expedientes en el archivo CSV."""
    # Abre el archivo en modo escritura ("w") para actualizar su contenido
    with open(ARCHIVO, "w", newline="", encoding="utf-8") as archivo:
        escritor = csv.writer(archivo)
        escritor.writerow(ENCABEZADOS)  # Escribe la fila de títulos
        for exp in expedientes:
            # Escribe cada expediente como una fila de valores
            escritor.writerow([
                exp["codigo"],
                exp["dni"],
                exp["ciudadano"],
                exp["tipo_documento"],
                exp["asunto"],
                exp["descripcion"],
                exp["fecha_recepcion"],
                exp["area_responsable"],
                exp["estado"],
            ])


def pedir_texto(mensaje):
    """Solicita un texto obligatorio y repite si está vacío."""
    texto = input(mensaje).strip()  # Quita espacios al inicio y al final
    while texto == "":
        print("  [!] Este campo no puede quedar vacío.")
        texto = input(mensaje).strip()
    return texto


def pedir_dni():
    """Solicita y valida que el DNI tenga 8 dígitos numéricos."""
    dni = input("  DNI (8 dígitos): ").strip()
    # isdigit() revisa que sean solo números y len(dni) == 8 revisa la longitud
    while not (dni.isdigit() and len(dni) == 8):
        print("  [!] DNI inválido. Ingrese exactamente 8 números.")
        dni = input("  DNI (8 dígitos): ").strip()
    return dni


def generar_codigo(expedientes):
    """Genera un código único como EXP-0001, EXP-0002, etc."""
    numero = len(expedientes) + 1
    while True:
        codigo = f"EXP-{numero:04d}"  # Formatea con ceros a la izquierda (4 dígitos)
        existe = False
        for exp in expedientes:
            if exp["codigo"] == codigo:
                existe = True
                break
        if not existe:
            return codigo
        numero += 1  # Si ya existe el código, prueba con el siguiente número


def registrar_expediente(expedientes):
    """Pide los datos, crea un expediente y lo guarda."""
    print("\n" + "-" * 48)
    print("           REGISTRO DE EXPEDIENTE")
    print("-" * 48)

    # Pide y valida cada dato del trámite
    dni = pedir_dni()
    ciudadano = pedir_texto("  Nombres y apellidos: ")
    tipo_documento = pedir_texto("  Tipo de documento: ")
    asunto = pedir_texto("  Asunto: ")
    descripcion = pedir_texto("  Descripción: ")
    area = pedir_texto("  Área responsable: ")
    fecha = datetime.now().strftime("%d/%m/%Y %H:%M")  # Fecha y hora actual

    # Arma el diccionario con los datos del nuevo expediente
    nuevo = {
        "codigo": generar_codigo(expedientes),
        "dni": dni,
        "ciudadano": ciudadano,
        "tipo_documento": tipo_documento,
        "asunto": asunto,
        "descripcion": descripcion,
        "fecha_recepcion": fecha,
        "area_responsable": area,
        "estado": "Recibido",  # Estado inicial por defecto
    }

    expedientes.append(nuevo)  # Agrega el expediente a la lista en memoria
    guardar_expedientes(expedientes)  # Guarda los cambios en el CSV

    print("-" * 48)
    print("  [OK] Expediente registrado correctamente.")
    print(f"       Código: {nuevo['codigo']}")
    print(f"       Fecha:  {nuevo['fecha_recepcion']}")
    print("-" * 48)


def mostrar_detalle(exp):
    """Muestra todos los campos de un expediente en pantalla."""
    print("\n" + "=" * 48)
    print("             DETALLE DEL EXPEDIENTE")
    print("=" * 48)
    print(f"  Código:           {exp['codigo']}")
    print(f"  DNI:              {exp['dni']}")
    print(f"  Ciudadano:        {exp['ciudadano']}")
    print(f"  Tipo documento:   {exp['tipo_documento']}")
    print(f"  Asunto:           {exp['asunto']}")
    print(f"  Descripción:      {exp['descripcion']}")
    print(f"  Fecha recepción:  {exp['fecha_recepcion']}")
    print(f"  Área responsable: {exp['area_responsable']}")
    print(f"  Estado:           {exp['estado']}")
    print("=" * 48)


def buscar_expediente(expedientes):
    """Busca un expediente por su código y muestra su detalle."""
    print("\n" + "-" * 48)
    print("          CONSULTA POR CÓDIGO")
    print("-" * 48)
    codigo = pedir_texto("  Código (ej. EXP-0001): ").upper()

    for exp in expedientes:
        if exp["codigo"].upper() == codigo:
            mostrar_detalle(exp)
            return  # Termina la función apenas lo encuentra

    print("  [!] No se encontró ningún expediente con ese código.")


def ordenar_burbuja(expedientes):
    """Ordena una copia de los expedientes por código usando burbuja."""
    lista = expedientes.copy()  # Copia para no alterar la lista original
    n = len(lista)

    for i in range(n):
        # En cada pasada, el elemento mayor va quedando al final
        for j in range(0, n - i - 1):
            if lista[j]["codigo"] > lista[j + 1]["codigo"]:
                # Intercambia posiciones usando una variable auxiliar
                aux = lista[j]
                lista[j] = lista[j + 1]
                lista[j + 1] = aux

    return lista


def listar_expedientes(expedientes):
    """Muestra los expedientes ordenados en formato de tabla."""
    print("\n" + "=" * 78)
    print("                     LISTA DE EXPEDIENTES (ORDENADOS)")
    print("=" * 78)

    if len(expedientes) == 0:
        print("  No hay expedientes registrados todavía.")
        print("=" * 78)
        return

    ordenados = ordenar_burbuja(expedientes)
    cabecera = (
        f"{'CÓDIGO':<10} | {'CIUDADANO':<24} | "
        f"{'ASUNTO':<24} | {'ESTADO':<11}"
    )
    print(cabecera)
    print("-" * 78)

    for exp in ordenados:
        # Recorta cada texto al ancho máximo de su columna
        codigo = exp["codigo"][:10]
        ciudadano = exp["ciudadano"][:24]
        asunto = exp["asunto"][:24]
        estado = exp["estado"][:11]
        fila = (
            f"{codigo:<10} | {ciudadano:<24} | "
            f"{asunto:<24} | {estado:<11}"
        )
        print(fila)

    print("=" * 78)


def main():
    """Función principal que muestra el menú y controla el programa."""
    expedientes = cargar_expedientes()  # Carga datos previos al iniciar

    while True:
        print("\n" + "=" * 48)
        print("        MESA DE PARTES DIGITAL")
        print("=" * 48)
        print("  1. Registrar expediente")
        print("  2. Consultar expediente por código")
        print("  3. Mostrar expedientes ordenados")
        print("  4. Salir")
        print("=" * 48)

        opcion = input("  Seleccione una opción (1-4): ").strip()

        if opcion == "1":
            registrar_expediente(expedientes)
        elif opcion == "2":
            buscar_expediente(expedientes)
        elif opcion == "3":
            listar_expedientes(expedientes)
        elif opcion == "4":
            print("\n  Gracias por usar el sistema. ¡Hasta luego!")
            break  # Sale del ciclo while y termina el programa
        else:
            print("\n  [!] Opción no válida. Elija entre 1 y 4.")

        input("\n  Presione ENTER para continuar...")


# Ejecuta main() solo si este archivo se corre directamente
if __name__ == "__main__":
    main()
